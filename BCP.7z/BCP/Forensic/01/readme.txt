A group of hackers broke our site, you will need to analyze the log and tell us the network with most dropped traffic against our server.

Answer format
BCP{network_with_most_dropped_traffic}