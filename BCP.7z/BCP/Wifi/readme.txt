A rogue AP was found in the BCP building, your task is to find out the password to log on to that network.

Hint
It begins with the string bcp, also the password may contain alphanumeric characters, good luck!

Attachment